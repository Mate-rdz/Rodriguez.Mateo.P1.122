package Parcial;

import java.util.*;

public class Acuario {
    private List<Animal> animales;

    public Acuario() {
        this.animales = new ArrayList<>();
    }

    public void agregarAnimal(Animal a) throws AnimalDuplicadoException {
        boolean existe = animales.stream()
            .anyMatch(x -> x.getNombre().equalsIgnoreCase(a.getNombre())
                         && x.getTanque().equalsIgnoreCase(a.getTanque()));
        if (existe) {
            throw new AnimalDuplicadoException("Ya existe un animal con nombre '" + a.getNombre()
                + "' en el tanque '" + a.getTanque() + "'.");
        }
        animales.add(a);
    }

    public void mostrarAnimales() {
        System.out.println("-- Animales registrados --");
        animales.forEach(a -> System.out.println(a.toString()));
    }

    public void nadar(String nombre, String tanque) {
        Optional<Animal> opt = buscarPorNombreTanque(nombre, tanque);
        if (opt.isEmpty()) {
            System.out.println("No se encontró animal con nombre " + nombre + " en " + tanque);
            return;
        }
        Animal a = opt.get();
        if (a instanceof Nadable) {
            ((Nadable)a).nadar();
        } else {
            System.out.println(a.getNombre() + " no puede nadar.");
        }
    }

    public void buscarAlimento(String nombre, String tanque) {
        Optional<Animal> opt = buscarPorNombreTanque(nombre, tanque);
        if (opt.isEmpty()) {
            System.out.println("No se encontró animal con nombre " + nombre + " en " + tanque);
            return;
        }
        Animal a = opt.get();
        if (a instanceof BuscadorAlimento) {
            ((BuscadorAlimento)a).buscarAlimento();
        } else {
            System.out.println(a.getNombre() + " no puede buscar alimento.");
        }
    }

    public List<Animal> filtrarPorTipoAgua(TipoAgua tipo) {
        List<Animal> res = new ArrayList<>();
        for (Animal a : animales) {
            if (a.getTipoAgua() == tipo) res.add(a);
        }
        System.out.println("-- Animales en " + tipo + " --");
        res.forEach(System.out::println);
        return res;
    }

    public void mostrarAnimalesPorTipo(String tipoAnimal) {
        System.out.println("-- Animales del tipo: " + tipoAnimal + " --");
        for (Animal a : animales) {
            String className = a.getClass().getSimpleName().toLowerCase();
            if (className.equals(tipoAnimal.toLowerCase())) {
                System.out.println(a);
            }
        }
    }

    private Optional<Animal> buscarPorNombreTanque(String nombre, String tanque) {
        return animales.stream()
            .filter(x -> x.getNombre().equalsIgnoreCase(nombre) && x.getTanque().equalsIgnoreCase(tanque))
            .findFirst();
    }
}
