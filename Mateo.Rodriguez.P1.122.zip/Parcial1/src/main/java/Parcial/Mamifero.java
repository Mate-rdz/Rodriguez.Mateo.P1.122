package Parcial;

public class Mamifero extends Animal implements Nadable, BuscadorAlimento {
    private int frecuenciaRespiracion; 

    public Mamifero(String nombre, String tanque, TipoAgua tipoAgua, int frecuenciaRespiracion) {
        super(nombre, tanque, tipoAgua);
        this.frecuenciaRespiracion = frecuenciaRespiracion;
    }

    public int getFrecuenciaRespiracion() {
        return frecuenciaRespiracion;
    }

    @Override
    public void nadar() {
        System.out.println(getNombre() + " (mamifero) nada con frecuencia de respiración " + frecuenciaRespiracion + "s.");
    }

    @Override
    public void buscarAlimento() {
        System.out.println(getNombre() + " (mamifero) busca alimento.");
    }

    @Override
    public String toString() {
        return super.toString() + String.format(", FrecuenciaRespiracion: %d s", frecuenciaRespiracion);
    }
}
