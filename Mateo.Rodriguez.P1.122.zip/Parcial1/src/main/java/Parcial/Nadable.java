package Parcial;

public interface Nadable {
    void nadar();
}
