package Parcial;

public abstract class Animal {
    private String nombre;
    private String tanque;
    private TipoAgua tipoAgua;

    public Animal(String nombre, String tanque, TipoAgua tipoAgua) {
        this.nombre = nombre;
        this.tanque = tanque;
        this.tipoAgua = tipoAgua;
    }

    public String getNombre() {
        return nombre;
    }

    public String getTanque() {
        return tanque;
    }

    public TipoAgua getTipoAgua() {
        return tipoAgua;
    }

    @Override
    public String toString() {
        return String.format("%s (Tanque: %s, Agua: %s)", nombre, tanque, tipoAgua);
    }
}

