package Parcial;

public class MainAcuario {
    public static void main(String[] args) {
        Acuario acuario = new Acuario();

        try {
            acuario.agregarAnimal(new Pez("Nemo", "TanqueTropical", TipoAgua.SALADA, 11.5));
            acuario.agregarAnimal(new Mamifero("Dory", "TanqueGrande", TipoAgua.SALADA, 8));
            acuario.agregarAnimal(new Crustaceo("Cangrejo", "Rocoso", TipoAgua.SALADA, 6));

        } catch (AnimalDuplicadoException ex) {
            System.err.println("Error: " + ex.getMessage());
        }

        acuario.mostrarAnimales();

        acuario.nadar("Nemo", "TanqueTropical");         
        acuario.nadar("Cangrejo", "Rocoso");            
        acuario.buscarAlimento("Dory", "TanqueGrande"); 
        acuario.buscarAlimento("Nemo", "TanqueTropical");
        acuario.filtrarPorTipoAgua(TipoAgua.SALADA);

        acuario.mostrarAnimalesPorTipo("Pez");
    }
}
