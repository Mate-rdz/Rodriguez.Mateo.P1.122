package Parcial;

public enum TipoAgua {
    DULCE,
    SALADA
}
