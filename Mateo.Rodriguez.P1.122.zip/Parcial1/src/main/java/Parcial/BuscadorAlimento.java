package Parcial;

public interface BuscadorAlimento {
    void buscarAlimento();
}
