package Parcial;

public class AnimalDuplicadoException extends Exception {
    public AnimalDuplicadoException(String mensaje) {
        super(mensaje);
    }
}
