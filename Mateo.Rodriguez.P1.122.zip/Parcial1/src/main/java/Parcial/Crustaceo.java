package Parcial;

public class Crustaceo extends Animal implements BuscadorAlimento {
    private int numeroPatas;

    public Crustaceo(String nombre, String tanque, TipoAgua tipoAgua, int numeroPatas) {
        super(nombre, tanque, tipoAgua);
        this.numeroPatas = numeroPatas;
    }

    public int getNumeroPatas() {
        return numeroPatas;
    }

    @Override
    public void buscarAlimento() {
        System.out.println(getNombre() + " (crustáceo) busca alimento con " + numeroPatas + " patas.");
    }

    @Override
    public String toString() {
        return super.toString() + String.format(", NumeroPatas: %d", numeroPatas);
    }
}

