package Parcial;

public class Pez extends Animal implements Nadable {
    private double longitudMaxima;

    public Pez(String nombre, String tanque, TipoAgua tipoAgua, double longitudMaxima) {
        super(nombre, tanque, tipoAgua);
        this.longitudMaxima = longitudMaxima;
    }

    public double getLongitudMaxima() {
        return longitudMaxima;
    }

    @Override
    public void nadar() {
        System.out.println(getNombre() + " (pez) esta nadando.");
    }

    public void alimentar() {
        System.out.println(getNombre() + " (pez) se esta alimentando.");
    }

    @Override
    public String toString() {
        return super.toString() + String.format(", LongitudMax: %.2f cm", longitudMaxima);
    }
}
